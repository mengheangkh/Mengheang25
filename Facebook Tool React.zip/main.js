// Facebook SDK Init
window.fbAsyncInit = function() {
  FB.init({
    appId: 'YOUR_FB_APP_ID',
    cookie: true,
    xfbml: true,
    version: 'v17.0'
  });
  
  FB.getLoginStatus(function(response) {
    statusChangeCallback(response);
  });
};

function statusChangeCallback(response) {
  if (response.status === 'connected') {
    console.log('Logged in:', response.authResponse.accessToken);
  } else {
    document.getElementById('fb-login-btn').style.display = 'block';
  }
}

function fbLogin() {
  FB.login(function(response) {
    if (response.authResponse) {
      console.log('Access Token:', response.authResponse.accessToken);
    } else {
      alert('Login cancelled or not authorized.');
    }
  }, { scope: 'public_profile,email' });
}

function toggleDarkMode() {
  document.body.classList.toggle('dark');
  let icon = document.getElementById('darkToggle');
  icon.textContent = document.body.classList.contains('dark') ? '🔅' : '🔆';
}

// Update estimated time
document.getElementById('count').addEventListener('input', () => {
  const count = parseInt(document.getElementById('count').value);
  const seconds = Math.ceil(count / 2); // 10 reactions = 5 sec
  document.getElementById('durationDisplay').textContent = `Estimated Duration: ${seconds} seconds`;
});

function sendReaction() {
  const postID = document.getElementById('postID').value.trim();
  const reaction = document.getElementById('reaction').value;
  const count = parseInt(document.getElementById('count').value);
  
  if (!postID || count > 1000 || count < 1) {
    alert("Please check Post ID and ensure count is between 1 and 1000.");
    return;
  }
  
  const loading = document.getElementById('loading');
  const result = document.getElementById('result');
  loading.style.display = 'block';
  result.innerHTML = "";
  
  let done = 0;
  const interval = setInterval(() => {
    done++;
    console.log(`Reacted with ${reaction} to ${postID} (${done})`);
    
    if (done >= count) {
      clearInterval(interval);
      loading.style.display = 'none';
      result.innerHTML = `✅ Successfully reacted ${count} times with ${reaction}`;
    }
    
  }, 500); // 10 reactions = 5 sec => 1 every 500ms
}